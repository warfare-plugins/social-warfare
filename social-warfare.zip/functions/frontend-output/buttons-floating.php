<?php

/**

 * ***************************************************************
 *                                                                *
 *          Side Fixed Floater Function				              *
 *                                                                *
 ******************************************************************/

/**
*
* @since 3.0.0 Added checks and classes for float_verical and float_button_size
*/
